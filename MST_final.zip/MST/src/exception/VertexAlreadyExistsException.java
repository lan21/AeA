package exception;

public class VertexAlreadyExistsException extends Exception {

	private static final long serialVersionUID = 1L;

}
