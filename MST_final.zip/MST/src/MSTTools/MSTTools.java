package MSTTools;

import graph.Itf.Graph;

public interface MSTTools {
    public void runPrim(Graph g);
    public void runKruskal(Graph g);
}