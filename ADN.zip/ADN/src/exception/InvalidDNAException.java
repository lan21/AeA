package exception;

public class InvalidDNAException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
