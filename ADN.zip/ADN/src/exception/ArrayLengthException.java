package exception;

public class ArrayLengthException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
