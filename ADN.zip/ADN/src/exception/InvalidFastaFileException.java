package exception;

public class InvalidFastaFileException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
