package ADN;

import java.util.Arrays;

/**
 * La Classe ADN represente l' ADN
 * 
 * @author tello
 * 
 */
public class ADN {
	/**
	 * Le brin de l' ADN
	 */
	private char[] brin;

	/**
	 * Constructeur
	 * 
	 * @param size
	 */
	public ADN(int size) {
		brin = new char[size];
	}

	/**
	 * Constructeur
	 * 
	 * @param brin
	 */
	public ADN(char[] brin) {
		this.brin = brin;
	}

	/**
	 * @return Le brin reverse du brin de l'ADN
	 */
	public char[] brin_reverse() {
		char[] reverse = new char[this.brin.length];
		int j = 0;
		for (int i = this.brin.length - 1; i >= 0; i--) {
			reverse[j] = this.brin[i];
			j++;
		}
		return reverse;
	}

	/**
	 * 
	 * @return Le brin complementaire du brin de l'ADN
	 * @throws IllegalArgumentException
	 */
	public char[] complementaire() throws IllegalArgumentException {
		char[] comp = new char[this.brin.length];
		for (int i = 0; i < this.brin.length; i++) {
			switch (this.brin[i]) {
			case 'A':
				comp[i] = 'T';
				break;
			case 'T':
				comp[i] = 'A';
				break;
			case 'G':
				comp[i] = 'C';
				break;
			case 'C':
				comp[i] = 'G';
				break;
			default:
				throw new IllegalArgumentException();
			}
		}
		return comp;
	}

	/**
	 * 
	 * @return Le brin reverse complementaire du brin de l'ADN
	 * @throws IllegalArgumentException
	 */
	public char[] reverse_complementaire() throws IllegalArgumentException {
		char[] tmp = new char[this.brin.length];
		tmp = this.brin_reverse();
		ADN a = new ADN(tmp);
		return a.complementaire();
	}

	public char[] getBrin() {
		return brin;
	}

	public void setBrin(char[] brin) {
		this.brin = brin;
	}

	/**
	 * Un brin1 est égal à un brin2 si tous les lettre des brin1 ou 2 sont égals
	 * ou le brin1 est le reverse du brin2 ou le brin1 est le complement du
	 * brin2 ou le brin1 est le reverse complent du brin2
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ADN other = (ADN) obj;
		try {
			if ((Arrays.equals(this.brin, other.brin))
					|| (Arrays.equals(this.complementaire(), other.brin))
					|| (Arrays.equals(this.brin_reverse(), other.brin))
					|| (Arrays
							.equals(this.reverse_complementaire(), other.brin)))
				return true;
		} catch (IllegalArgumentException e) {
			return false;
		}

		return false;
	}
}