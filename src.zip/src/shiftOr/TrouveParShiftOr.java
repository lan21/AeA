package shiftOr;


import ADN.ADN;

public class TrouveParShiftOr {

		
	public static ShiftOr shift;
	
	/**
	 * Trouver tous les motif dans le brin d'ADN
	 * 
	 * @param brin
	 * @param motif
	 */
	public static void trouve_pour_le_motif_exact(char[] brin, char[] motif) {
		System.out.print("Le motif exact: ");
		System.out.println(motif);
		shift = new ShiftOr(brin, motif);
		try {
			shift.genererLesVerctorsU();
			shift.remplireMatrice();
			shift.trouveMotif();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * trouve tous les reverse d'un motif dans le brin d'ADN
	 * 
	 * @param brin
	 * @param motif
	 * @throws Exception
	 */
	public static void trouve_pour_le_reverse_du_motif(char[] brin, char[] motif)
			throws Exception {
		ADN a = new ADN(motif);
		System.out.print("Le reverse: ");
		System.out.println(a.brin_reverse());
		shift = new ShiftOr(brin, a.brin_reverse());
		try {
			shift.genererLesVerctorsU();
			shift.remplireMatrice();
			shift.trouveMotif();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Trouver tous les complement d'un motif dans le brin d'ADN
	 * 
	 * @param brin
	 * @param motif
	 * @throws Exception
	 */
	public static void trouve_pour_le_complementaire_du_motif(char[] brin,
			char[] motif) throws Exception {
		ADN a = new ADN(motif);
		System.out.print("Le brin complementaire: ");
		System.out.println(a.complementaire());
		shift = new ShiftOr(brin, a.complementaire());
		try {
			shift.genererLesVerctorsU();
			shift.remplireMatrice();
			shift.trouveMotif();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Trouver tous les reverse complement d'un motif dans le brin d'ADN
	 * 
	 * @param brin
	 * @param motif
	 * @throws Exception
	 */
	public static void trouve_pour_le_reverse_complementaire_du_motif(
			char[] brin, char[] motif) throws Exception {
		ADN a = new ADN(motif);
		System.out.print("Le brin reverse complementaire: ");
		System.out.println(a.reverse_complementaire());
		 shift = new ShiftOr(brin, a.reverse_complementaire());
		try {
			shift.genererLesVerctorsU();
			shift.remplireMatrice();
			shift.trouveMotif();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
