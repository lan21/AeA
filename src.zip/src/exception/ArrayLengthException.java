package exception;

public class ArrayLengthException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4350066976269318335L;

	public ArrayLengthException() {
		System.out.println("Les deux array n'ont pas la même taille");
	}
}
