package exception;

public class InvalidADNException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 4700470734312516045L;

	public InvalidADNException() {
		System.out.println("Invalid caracter in the AND sequance");
	}
}
