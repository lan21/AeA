package Algorithm;

public interface AlgoColor {

	public int getNumberOfUsedColors();

}